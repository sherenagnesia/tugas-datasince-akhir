@echo off
setlocal
cd /d "%~dp0"
title Dashboard Klasifikasi Dataset

set PY=
where python >nul 2>nul && set PY=python
if not defined PY (where py >nul 2>nul && set PY=py)
if not defined PY (
  echo Python belum terpasang. Pasang Python 3.10+ dari https://www.python.org/downloads/
  echo Centang "Add Python to PATH" saat instalasi, lalu jalankan file ini lagi.
  pause
  exit /b 1
)

if not exist ".venv" (
  echo [1/3] Membuat lingkungan virtual...
  %PY% -m venv .venv
)
call ".venv\Scripts\activate.bat"

if not exist "%USERPROFILE%\.streamlit\credentials.toml" (
  mkdir "%USERPROFILE%\.streamlit" 2>nul
  (echo [general]& echo email = "")> "%USERPROFILE%\.streamlit\credentials.toml"
)

echo [2/3] Memasang library (pertama kali agak lama)...
python -m pip install --upgrade pip -q
pip install -r requirements.txt -q
if errorlevel 1 (
  echo Gagal memasang library. Periksa koneksi internet.
  pause
  exit /b 1
)

echo [3/3] Menjalankan dashboard...
echo Buka di browser: http://localhost:8501  (tutup jendela ini untuk menghentikan)
streamlit run app.py --server.port 8501
pause
