# Dashboard Klasifikasi Dataset (Streamlit)

## Cara menjalankan (localhost)
- **Windows**: klik dua kali `run.bat`
- **macOS / Linux**: `bash run.sh`

Pertama kali, script memasang library otomatis (butuh internet). Setelah itu browser terbuka
di **http://localhost:8501**. Jika tidak terbuka sendiri, salin alamat itu ke browser.

Manual: `pip install -r requirements.txt` lalu `streamlit run app.py`

## Cara memakai
1. Unggah CSV (hanya sekali), pilih atribut kelas, klik **Kunci dataset**.
2. Buka tab: Overview -> Data Understanding -> Preprocessing -> Modeling -> Evaluation.
3. Untuk ganti dataset: refresh halaman.

`sample_dataset.csv` = data SIMULASI untuk uji coba (kolom kelas: `sentiment`),
bukan data asli dari Kaggle.
